package com.example.duanquanlysinhvien.model;

public class ChucNang {
    private String name;

    public ChucNang(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

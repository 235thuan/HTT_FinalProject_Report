package com.example.duanquanlysinhvien.sinhvien;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import android.widget.Button;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.danhsach.DanhSachSinhVien;

import java.util.Calendar;

public class SinhVienThem extends AppCompatActivity {
    private EditText edtMsv, edtHotenSv, edtDob;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sinh_vien_them);

        // Ensure dbHelper is initialized
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtMsv = findViewById(R.id.edt_msv);
        edtHotenSv = findViewById(R.id.edt_hotensv);
        edtDob = findViewById(R.id.edt_dob);
        Button btnThemSinhVien = findViewById(R.id.btnThemSinhVien);
        ImageView imgBackHome = findViewById(R.id.imgBackHome);

        // Set back button listener
        imgBackHome.setOnClickListener(v -> {
            Intent intent = new Intent(SinhVienThem.this, DanhSachSinhVien.class);
            startActivity(intent);
        });

        // Open DatePickerDialog on DOB field click
        edtDob.setOnClickListener(v -> openDatePicker());

        // Register student on button click
        btnThemSinhVien.setOnClickListener(v -> registerStudent());
    }

    private void openDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                SinhVienThem.this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String dob = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    edtDob.setText(dob);
                },
                year, month, day
        );
        datePickerDialog.show();
    }

    private void registerStudent() {
        String msv = edtMsv.getText().toString().trim();
        String hotenSv = edtHotenSv.getText().toString().trim();
        String dob = edtDob.getText().toString().trim();

        // Validate inputs
        if (msv.isEmpty() || hotenSv.isEmpty() || dob.isEmpty()) {
            Toast.makeText(this, "Vui lòng điền đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dbHelper.checkUsernameExists(hotenSv)) {
            Toast.makeText(this, "Tên đăng nhập đã tồn tại!", Toast.LENGTH_SHORT).show();
            return;
        }
        // Insert student to database
        boolean success = dbHelper.registerStudent(msv, hotenSv, dob);

        if (success) {
            Toast.makeText(this, "Đăng ký sinh viên thành công", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(SinhVienThem.this, DanhSachSinhVien.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Đăng ký thất bại. Vui lòng thử lại!", Toast.LENGTH_SHORT).show();
        }
    }
}

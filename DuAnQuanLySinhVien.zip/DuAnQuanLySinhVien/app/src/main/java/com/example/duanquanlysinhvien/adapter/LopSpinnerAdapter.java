package com.example.duanquanlysinhvien.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.duanquanlysinhvien.model.Khoa;
import com.example.duanquanlysinhvien.model.Lop;

import java.util.List;

public class LopSpinnerAdapter extends ArrayAdapter<Lop> {
    public LopSpinnerAdapter(Context context, List<Lop> majors) {
        super(context, android.R.layout.simple_spinner_item, majors);
        setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Lop major = getItem(position);
        TextView textView = (TextView) super.getView(position, convertView, parent);
        textView.setText(major.getName());
        return textView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        Lop lop = getItem(position);
        TextView textView = (TextView) super.getDropDownView(position, convertView, parent);
        textView.setText(lop.getName());
        return textView;
    }
}
package com.example.duanquanlysinhvien.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.danhsach.DanhSachChucNang;
import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.MainActivity;
import com.example.duanquanlysinhvien.R;

public class DangNhap extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private EditText edt_tenDangNhap;
    private EditText editTextTextPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dang_nhap);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DatabaseHelper(this);
        edt_tenDangNhap = findViewById(R.id.edt_tenDangNhap);
        editTextTextPassword = findViewById(R.id.editTextTextPassword);

        ImageView imgBackHome = findViewById(R.id.imgBackHome);
        Button btnDang_nhap = findViewById(R.id.btnDang_nhap);

        // Set an OnClickListener on the button
        imgBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start MenuActivity
                Intent intent = new Intent(DangNhap.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnDang_nhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edt_tenDangNhap.getText().toString().trim();
                String password = editTextTextPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(DangNhap.this, "Vui lòng nhập tên đăng nhập và mật khẩu", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Validate credentials
                if (dbHelper.validateUser(username, password)) {
                    // Login successful, navigate to the next activity
                    Intent intent = new Intent(DangNhap.this, DanhSachChucNang.class);
                    startActivity(intent);
                    Toast.makeText(DangNhap.this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
                } else {
                    // Show error message if credentials are invalid
                    Toast.makeText(DangNhap.this, "Tên đăng nhập hoặc mật khẩu không đúng", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
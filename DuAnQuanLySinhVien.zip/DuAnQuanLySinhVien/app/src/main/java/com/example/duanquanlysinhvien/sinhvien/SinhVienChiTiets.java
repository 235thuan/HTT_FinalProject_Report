package com.example.duanquanlysinhvien.sinhvien;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.MainActivity;
import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.adapter.GridImageAdapter;
import com.example.duanquanlysinhvien.auth.DangKy;
import com.example.duanquanlysinhvien.danhsach.DanhSachSinhVien;


public class SinhVienChiTiets extends AppCompatActivity {
    private ListView lvThongTinCaNhanMenu;
    private ListView lvMonHocMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_chi_tiet_sinh_vien);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageView menu_back = findViewById(R.id.menu_back);
        menu_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start MenuActivity
                Intent intent = new Intent(SinhVienChiTiets.this, DanhSachSinhVien.class);
                startActivity(intent);
                finish();
            }
        });
        int[] imagesSection1 = {
                R.drawable.a4, R.drawable.a1, R.drawable.a2,
                R.drawable.a6, R.drawable.a5, R.drawable.a3
        };
        String[] textsSection1 = {
                "Khoa", "Lớp", "Bạn bè",
                "Thành tích", "Thời khóa biểu", "Học phí "
        };

        int[] imagesSection2 = {
                R.drawable.a7, R.drawable.a8, R.drawable.a9,
                R.drawable.a10, R.drawable.a11, R.drawable.a12
        };
        String[] textsSection2 = {
                "Lập trình cơ bản", "Phân tích thiết kế", "Giáo dục thể chất",
                "Toán cao cấp", "Photoshop", "Illustrator"
        };

        // Set up first grid section
        GridView gridSection1 = findViewById(R.id.grid_section_1);
        GridImageAdapter adapter1 = new GridImageAdapter(this, imagesSection1,textsSection1);
        gridSection1.setAdapter(adapter1);

        // Set up second grid section
        GridView gridSection2 = findViewById(R.id.grid_section_2);
        GridImageAdapter adapter2 = new GridImageAdapter(this, imagesSection2,textsSection2);
        gridSection2.setAdapter(adapter2);
    }
}

package com.example.duanquanlysinhvien.sinhvien;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.adapter.KhoaSpinnerAdapter;
import com.example.duanquanlysinhvien.adapter.LopSpinnerAdapter;
import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.danhsach.DanhSachChucNang;
import com.example.duanquanlysinhvien.danhsach.DanhSachSinhVien;
import com.example.duanquanlysinhvien.lop.LopThem;
import com.example.duanquanlysinhvien.model.Khoa;
import com.example.duanquanlysinhvien.model.Lop;

import java.util.List;

public class SinhVienSua extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private Spinner spinnerMajor, spinnerClass;
    private EditText edt_tenDangNhap; // EditText for student name
    private EditText editTextPassword; // EditText for student name
    private EditText edt_hotensv; // EditText for student name
    private EditText edt_dob; // EditText for student name
    private EditText edt_msv; // EditText for student name

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sinh_vien_sua);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);
        spinnerMajor = findViewById(R.id.spinner_major);
        spinnerClass = findViewById(R.id.spinner_class);
        Button btnUpdateStudent = findViewById(R.id.btnDangKy);
        ImageView imgBackHome = findViewById(R.id.imgBackHome);

        Intent intent = getIntent();
        String msv = intent.getStringExtra("msv");
        String name = intent.getStringExtra("name");
        String dob = intent.getStringExtra("dob");


        edt_hotensv = findViewById(R.id.edt_hotensv);
        edt_dob = findViewById(R.id.edt_dob);
        edt_msv = findViewById(R.id.edt_msv);
        edt_hotensv.setText(name);
        edt_dob.setText(dob);
        edt_msv.setText(msv);

        // Populate the major spinner
        populateMajorSpinner();
        populateClassSpinner();

        imgBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start MenuActivity
                Intent intent = new Intent(SinhVienSua.this, DanhSachSinhVien.class);
                startActivity(intent);
                finish();
            }
        });
        btnUpdateStudent.setOnClickListener(v -> updateStudent());
    }

    private void populateMajorSpinner() {
        // Fetch major data from the database
        List<Khoa> majors = dbHelper.getAllMajors();
        spinnerMajor = findViewById(R.id.spinner_major);

        // Create an ArrayAdapter using the Khoa objects
        ArrayAdapter<Khoa> majorAdapter = new ArrayAdapter<Khoa>(this, android.R.layout.simple_spinner_item, majors) {
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView textView = (TextView) view;
                textView.setText(majors.get(position).getName()); // Set the major name
                textView.setTextColor(Color.parseColor("#F89D20")); // Change dropdown item color
                return view;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view;
                textView.setText(majors.get(position).getName()); // Set the major name
                textView.setTextColor(Color.parseColor("#F89D20")); // Change selected item color
                return view;
            }
        };

        majorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // Set the dropdown view
        spinnerMajor.setAdapter(majorAdapter);

        // Optional: Set a listener for item selection
        spinnerMajor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Handle the major selection here
                Khoa selectedMajor = (Khoa) parent.getItemAtPosition(position);
                Toast.makeText(SinhVienSua.this, "Selected: " + selectedMajor.getName(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }


    private void populateClassSpinner() {
        spinnerClass = findViewById(R.id.spinner_class);
        // Fetch major data from the database
        List<Lop> lops = dbHelper.getAllClass();

        // Create an ArrayAdapter using the Khoa objects
        ArrayAdapter<Lop> lopAdapter = new ArrayAdapter<Lop>(this, android.R.layout.simple_spinner_item, lops) {
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView textView = (TextView) view;
                textView.setText(lops.get(position).getName()); // Set the major name
                textView.setTextColor(Color.parseColor("#F89D20")); // Change dropdown item color
                return view;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view;
                textView.setText(lops.get(position).getName()); // Set the major name
                textView.setTextColor(Color.parseColor("#F89D20")); // Change selected item color
                return view;
            }
        };

        lopAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // Set the dropdown view
        spinnerClass.setAdapter(lopAdapter);

        // Optional: Set a listener for item selection
        spinnerClass.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Handle the major selection here
                Lop selectLop = (Lop) parent.getItemAtPosition(position);
                Toast.makeText(SinhVienSua.this, "Selected: " + selectLop.getName(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void updateStudent() {
        edt_tenDangNhap = findViewById(R.id.edt_tenDangNhap);
        editTextPassword = findViewById(R.id.editTextPassword);
        edt_hotensv = findViewById(R.id.edt_hotensv);
        edt_dob = findViewById(R.id.edt_dob);
        edt_msv = findViewById(R.id.edt_msv);
        String studentName = edt_hotensv.getText().toString().trim();
        String msv = edt_msv.getText().toString().trim();
        String studentDoB = edt_dob.getText().toString().trim();
        String studentUserName = edt_tenDangNhap.getText().toString().trim();
        String studentPassword = editTextPassword.getText().toString().trim();
        Khoa selectedMajor = (Khoa) spinnerMajor.getSelectedItem();
        Lop selectedClass = (Lop) spinnerClass.getSelectedItem();


        // Check for empty fields
        if (studentName.isEmpty()) {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (studentUserName.isEmpty()) {
            studentUserName = "null" + studentName;
        }
        if (studentPassword.isEmpty()) {
            studentUserName = "null" + studentName;
        }

        // Call the database helper to update the student
        boolean isUpdated = dbHelper.updateStudent(studentUserName, studentPassword, msv, studentName, studentDoB, selectedMajor.getName(), selectedClass.getName());

        if (isUpdated) {
            Toast.makeText(this, "Cập nhật sinh viên thành công.", Toast.LENGTH_SHORT).show();
            finish(); // Optionally finish the activity after update
        } else {
            Toast.makeText(this, "Cập nhật sinh viên thất bại.", Toast.LENGTH_SHORT).show();
        }
    }
}
package com.example.duanquanlysinhvien.khoa;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.MainActivity;
import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.danhsach.DanhSachChucNang;
import com.example.duanquanlysinhvien.sinhvien.SinhVienThem;

public class KhoaThem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_khoa_them);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        ImageView imgBackHome = findViewById(R.id.imgBackHome);
        Button registerMajor= findViewById(R.id.btnDangKy);
        EditText edt_TenKhoa =findViewById(R.id.edt_TenKhoa);
        imgBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start MenuActivity
                Intent intent = new Intent(KhoaThem.this, DanhSachChucNang.class);
                startActivity(intent);
                finish();
            }
        });
        registerMajor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String majorName = edt_TenKhoa.getText().toString().trim();

                boolean isSuccess = dbHelper.registerMajor(majorName, "Active", System.currentTimeMillis(), "Admin", System.currentTimeMillis(), "Admin");

                if (isSuccess) {
                    Toast.makeText(KhoaThem.this, "Thêm khoa thành công.", Toast.LENGTH_SHORT).show();
                    Log.d("Database", "Thêm khoa thành công.");
                    Intent intent = new Intent(KhoaThem.this, DanhSachChucNang.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(KhoaThem.this, "Thêm khoa thất bại", Toast.LENGTH_SHORT).show();
                    Log.d("Database", "Thêm khoa thất bại.");
                }

            }
        });
    }
}
package com.example.duanquanlysinhvien.model;

public class Khoa {
    private String name;
    private String status;
    private long updatedTime;
    private String updatedBy;
    private long createdTime;
    private String createdBy;

    // Constructor
    public Khoa(String name, String status, long updatedTime, String updatedBy, long createdTime, String createdBy) {
        this.name = name;
        this.status = status;
        this.updatedTime = updatedTime;
        this.updatedBy = updatedBy;
        this.createdTime = createdTime;
        this.createdBy = createdBy;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(long updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    @Override
    public String toString() {
        return name; // This will be displayed in the spinner
    }
}


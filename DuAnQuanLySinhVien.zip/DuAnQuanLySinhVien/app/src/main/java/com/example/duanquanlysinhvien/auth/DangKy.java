package com.example.duanquanlysinhvien.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.MainActivity;
import com.example.duanquanlysinhvien.R;

public class DangKy extends AppCompatActivity {
    private EditText edtTenDangNhap, edtMatKhau;
    private Button btnDangKy;
    private DatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dang_ky);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtTenDangNhap = findViewById(R.id.edt_tenDangNhap);
        edtMatKhau = findViewById(R.id.editTextTextPassword);
        btnDangKy = findViewById(R.id.btnDangKy);

        dbHelper = new DatabaseHelper(this);
        ImageView imgBackHome = findViewById(R.id.imgBackHome);
        btnDangKy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });
        imgBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start MenuActivity
                Intent intent = new Intent(DangKy.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void registerUser() {
        String username = edtTenDangNhap.getText().toString().trim();
        String password = edtMatKhau.getText().toString().trim();

        // Validate fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Vui lòng điền đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if username already exists
        if (dbHelper.checkUsernameExists(username)) {
            Toast.makeText(this, "Tên đăng nhập đã tồn tại!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Register the user
        boolean isRegistered = dbHelper.registerUser(username, password);
        if (isRegistered) {
            Toast.makeText(this, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(DangKy.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close registration activity
        } else {
            Toast.makeText(this, "Đăng ký thất bại. Vui lòng thử lại!", Toast.LENGTH_SHORT).show();
        }
    }
}
package com.example.duanquanlysinhvien.danhsach;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.MainActivity;
import com.example.duanquanlysinhvien.auth.DangNhap;
import com.example.duanquanlysinhvien.diem.DiemThem;
import com.example.duanquanlysinhvien.giaovien.GiaoVienThem;
import com.example.duanquanlysinhvien.khoa.KhoaThem;
import com.example.duanquanlysinhvien.lop.LopThem;
import com.example.duanquanlysinhvien.model.ChucNang;
import com.example.duanquanlysinhvien.adapter.ChucNangAdapter;
import com.example.duanquanlysinhvien.R;

import java.util.ArrayList;
import java.util.List;

public class DanhSachChucNang extends AppCompatActivity {
    private ChucNangAdapter menuAdapter;
    private List<ChucNang> menuItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_danh_sach_chuc_nang);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ListView listView = findViewById(R.id.lv_menuChucNang);
        ImageView imgBackMenuChucNang = findViewById(R.id.imgBackMenuChucNang);
        ImageView imgSetting = findViewById(R.id.imgSetting);


        // Initialize menu items
        menuItems = new ArrayList<>();
        menuItems.add(new ChucNang("Danh sách khoa"));
        menuItems.add(new ChucNang("Danh sách lớp"));
        menuItems.add(new ChucNang("Danh sách sinh viên"));

        menuAdapter = new ChucNangAdapter(this, menuItems);
        listView.setAdapter(menuAdapter);


        imgBackMenuChucNang.setOnClickListener(v -> {
            Intent intent = new Intent(DanhSachChucNang.this, MainActivity.class);
            startActivity(intent);
        });
        imgSetting.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                showSettingPopUp(v);
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        Intent danhsachkhoa = new Intent(DanhSachChucNang.this, DanhSachKhoa.class);
                        startActivity(danhsachkhoa);
                        Toast.makeText(DanhSachChucNang.this, "Danh sách khoa", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Intent danhsachlop = new Intent(DanhSachChucNang.this, DanhSachLop.class);
                        startActivity(danhsachlop);
                        Toast.makeText(DanhSachChucNang.this, "Danh sách lớp", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Intent danhsachsinhvien = new Intent(DanhSachChucNang.this, DanhSachSinhVien.class);
                        startActivity(danhsachsinhvien);
                        Toast.makeText(DanhSachChucNang.this, "Danh sách sinh viên", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }
    private void showSettingPopUp(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view, 0, 0, R.style.CustomPopupSettingMenu);
        popupMenu.getMenuInflater().inflate(R.menu.setting_danh_sach_chuc_nang, popupMenu.getMenu());

        // Handle clicks on menu items
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(item.getItemId()==R.id.menu_major_add) {
                    Intent loginIntent = new Intent(DanhSachChucNang.this, KhoaThem.class);
                    startActivity(loginIntent);
                    return true;
                } else if(item.getItemId()==R.id.menu_class_add) {
                    Intent loginIntent = new Intent(DanhSachChucNang.this, LopThem.class);
                    startActivity(loginIntent);
                    return true;
                } else if(item.getItemId()==R.id.menu_teacher_add) {
                    Intent loginIntent = new Intent(DanhSachChucNang.this, GiaoVienThem.class);
                    startActivity(loginIntent);
                    return true;
                } else if(item.getItemId()==R.id.menu_grade_add) {
                    Intent loginIntent = new Intent(DanhSachChucNang.this, DiemThem.class);
                    startActivity(loginIntent);
                    return true;
                }else {
                    return false;
                }

            }
        });

        popupMenu.show();

    }
}
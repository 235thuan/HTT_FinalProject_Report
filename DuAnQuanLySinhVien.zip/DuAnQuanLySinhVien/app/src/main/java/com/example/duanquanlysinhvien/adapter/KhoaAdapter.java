package com.example.duanquanlysinhvien.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.model.Khoa;

import java.util.List;

public class KhoaAdapter extends BaseAdapter {
    private List<Khoa> majorList; // List of Khoa objects
    private LayoutInflater inflater; // For inflating views

    // Constructor
    public KhoaAdapter(Context context, List<Khoa> majorList) {
        this.majorList = majorList;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return majorList.size(); // Return the size of the list
    }

    @Override
    public Khoa getItem(int position) {
        return majorList.get(position); // Return the Khoa object at the specified position
    }

    @Override
    public long getItemId(int position) {
        return position; // Return the position as the ID
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            // Inflate the layout if convertView is null
            convertView = inflater.inflate(R.layout.chucnang_item, parent, false);
        }

        // Get the Khoa object for this position
        Khoa currentMajor = getItem(position);

        // Find the TextView in the layout and set the major name
        TextView tvMenuItem = convertView.findViewById(R.id.tvMenuItem);
        tvMenuItem.setText(currentMajor.getName());

        return convertView; // Return the completed view
    }
}

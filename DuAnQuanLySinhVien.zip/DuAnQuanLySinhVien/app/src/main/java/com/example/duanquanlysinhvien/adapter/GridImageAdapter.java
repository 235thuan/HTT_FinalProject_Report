package com.example.duanquanlysinhvien.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.duanquanlysinhvien.R;

public class GridImageAdapter extends BaseAdapter {
    private Context context;
    private int[] images;
    private String[] texts; // Thêm mảng chứa văn bản cho mỗi ảnh

    public GridImageAdapter(Context context, int[] images,String[] texts) {
        this.context = context;
        this.images = images;
        this.texts = texts;
    }

    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return images[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.grid_item_image, parent, false);
        }

        ImageView imageView = convertView.findViewById(R.id.grid_item_image);
        TextView textView = convertView.findViewById(R.id.grid_item_text);
        imageView.setImageResource(images[position]);
        if(texts!=null){
            textView.setText(texts[position]);
        }


        return convertView;
    }
}

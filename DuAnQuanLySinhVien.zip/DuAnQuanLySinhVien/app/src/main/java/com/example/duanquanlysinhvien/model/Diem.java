package com.example.duanquanlysinhvien.model;

public class Diem {
    private String name;
    private String score;

    public Diem(String name, String score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public String getScore() {
        return score;
    }
}

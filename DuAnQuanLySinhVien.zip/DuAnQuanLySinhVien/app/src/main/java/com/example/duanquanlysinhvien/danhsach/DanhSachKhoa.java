package com.example.duanquanlysinhvien.danhsach;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.adapter.KhoaAdapter;
import com.example.duanquanlysinhvien.adapter.SinhVienAdapter;
import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.model.Khoa;
import com.example.duanquanlysinhvien.sinhvien.SinhVienThem;

import java.util.List;

public class DanhSachKhoa extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private ListView lv_menuKhoa;
    private List<Khoa> majorList;
    private KhoaAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_danh_sach_khoa);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageView menu_back = findViewById(R.id.menu_back);
        dbHelper = new DatabaseHelper(this);
        lv_menuKhoa = findViewById(R.id.lv_menuKhoa);
        menu_back.setOnClickListener(v -> {
            Intent intent = new Intent(DanhSachKhoa.this, DanhSachChucNang.class);
            startActivity(intent);
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        loadMajorData();
    }

    private void loadMajorData() {
        majorList = dbHelper.getAllMajors(); // Fetch major data from the database

        if (majorList.isEmpty()) {
            Toast.makeText(this, "No majors found.", Toast.LENGTH_SHORT).show();
        } else {
            adapter = new KhoaAdapter(this, majorList); // Create an adapter for major data
            lv_menuKhoa.setAdapter(adapter);
        }
    }
}
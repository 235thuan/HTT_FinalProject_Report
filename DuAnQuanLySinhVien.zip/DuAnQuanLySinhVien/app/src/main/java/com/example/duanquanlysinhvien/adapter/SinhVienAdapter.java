package com.example.duanquanlysinhvien.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.model.SinhVien;
import com.example.duanquanlysinhvien.sinhvien.SinhVienChiTiets;
import com.example.duanquanlysinhvien.sinhvien.SinhVienSua;

import java.util.ArrayList;
import java.util.List;

public class SinhVienAdapter extends BaseAdapter {
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private List<SinhVien> studentList;
    private Context context;
    private DatabaseHelper dbHelper;

    public SinhVienAdapter(Context context, List<SinhVien> studentList) {
        this.context = context;
        this.studentList = new ArrayList<>(studentList);
        this.dbHelper = new DatabaseHelper(context);
    }

    public void updateList(List<SinhVien> newStudentList) {
        studentList.clear();
        studentList.addAll(newStudentList);
        notifyDataSetChanged(); // Refresh the list view
    }

    @Override
    public int getCount() {
        return studentList.size() + 1; // +1 for the header
    }

    @Override
    public int getItemViewType(int position) {
        return (position == 0) ? TYPE_HEADER : TYPE_ITEM;
    }

    @Override
    public Object getItem(int position) {
        return (position == 0) ? null : studentList.get(position - 1);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int viewType = getItemViewType(position);

        if (viewType == TYPE_HEADER) {
            if (convertView == null) {
                // Inflate header layout if needed
                convertView = LayoutInflater.from(context).inflate(R.layout.item_sinhvien_header, parent, false);
            }
        } else {
            if (convertView == null) {
                // Inflate regular item layout if needed
                convertView = LayoutInflater.from(context).inflate(R.layout.sinhvien_item, parent, false);
            }

            // Adjust index without subtracting if there's no header
            int adjustedPosition = viewType == TYPE_ITEM ? position - 1 : position;
            SinhVien student = studentList.get(adjustedPosition);
            // Access and set views for each item
            TextView tvMSV = convertView.findViewById(R.id.tvMSV);
            TextView tvTSV = convertView.findViewById(R.id.tvTSV);
            ImageView imgXemChiTiet = convertView.findViewById(R.id.imgXemChiTiet);
            ImageView imgSua = convertView.findViewById(R.id.imgSua);
            ImageView imgXoa = convertView.findViewById(R.id.imgXoa);

            // Check for null and set data
            if (tvMSV != null) {
                System.out.println("set msv !");
                tvMSV.setText(student.getMsv());
            }
            if (tvTSV != null) {
                System.out.println(" set name ");
                tvTSV.setText(student.getName());
            }
            if (imgXemChiTiet != null) {
                imgXemChiTiet.setOnClickListener(v -> openStudentDetails(student));
            }
            if (imgSua != null) {
                imgSua.setOnClickListener(v -> editStudent(student));
            }
            if (imgXoa != null) {
                imgXoa.setOnClickListener(v -> showDeleteConfirmation(student));
            }
        }
        return convertView;
    }


    private void openStudentDetails(SinhVien student) {
        Intent sinhVienChiTiet = new Intent(context, SinhVienChiTiets.class);
        sinhVienChiTiet.putExtra("msv", student.getMsv());
        sinhVienChiTiet.putExtra("name", student.getName());
        sinhVienChiTiet.putExtra("dob", student.getDob());
        context.startActivity(sinhVienChiTiet);
    }

    private void editStudent(SinhVien student) {
        Intent sinhVienSua = new Intent(context, SinhVienSua.class);
        sinhVienSua.putExtra("msv", student.getMsv());
        sinhVienSua.putExtra("name", student.getName());
        sinhVienSua.putExtra("dob", student.getDob());
        context.startActivity(sinhVienSua);
    }

    private void showDeleteConfirmation(SinhVien student) {
        new AlertDialog.Builder(context)
                .setTitle("Xác nhận xóa")
                .setMessage("Bạn có chắc chắn muốn xóa sinh viên "+ student.getName()+ "  không?" )
                .setPositiveButton("Xóa", (dialog, which) -> deleteStudent(student))
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void deleteStudent(SinhVien student) {
        System.out.println("DeleteStudent Attempting to delete student with MSV: " + student.getMsv());
        boolean isDeleted = dbHelper.deleteStudent(student.getMsv());
        if (isDeleted) {
            studentList.remove(student);
            notifyDataSetChanged();
            Toast.makeText(context, "Sinh viên đã được xóa", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Không thể xóa sinh viên", Toast.LENGTH_SHORT).show();
        }
    }
}



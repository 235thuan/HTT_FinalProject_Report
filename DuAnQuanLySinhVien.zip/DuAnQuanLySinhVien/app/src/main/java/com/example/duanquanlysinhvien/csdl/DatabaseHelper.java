package com.example.duanquanlysinhvien.csdl;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.duanquanlysinhvien.model.Khoa;
import com.example.duanquanlysinhvien.model.Lop;
import com.example.duanquanlysinhvien.model.SinhVien;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Tên và phiên bản của cơ sở dữ liệu

    private static final String TABLE_USER = "user";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "userName";
    private static final String COLUMN_PASSWORD = "password";

    private static final String DATABASE_NAME = "school.db";
    private static final int DATABASE_VERSION = 3;
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Các cột chung trong bảng (Base table columns)
        String baseColumns = "status TEXT, updatedTime INTEGER, updatedBy TEXT, createdTime INTEGER, createdBy TEXT";

        // Bảng người dùng (User table)
        db.execSQL("CREATE TABLE user (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "userName TEXT, " +
                "password TEXT" +
                ");");

        // Bảng sinh viên kế thừa từ người dùng (Student table - extends User)
        db.execSQL("CREATE TABLE student (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "userId INTEGER, " +
                "msv TEXT, " +
                "name TEXT, " +
                "dob TEXT, " +
                "age INTEGER, " +
                "FOREIGN KEY (userId) REFERENCES user(id) ON DELETE CASCADE" +
                ");");


        // Bảng giáo viên kế thừa từ người dùng (Teacher table - extends User)
        db.execSQL("CREATE TABLE teacher (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "userId INTEGER, " +
                "staffId TEXT, " +
                "name TEXT, " +
                "FOREIGN KEY (userId) REFERENCES user(id)" +  // Khóa ngoại tham chiếu tới bảng user
                ");");

        // Bảng ngành học kế thừa từ bảng chung (Major table - extends Base)
        db.execSQL("CREATE TABLE major (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                baseColumns + // Các cột của bảng chung như trạng thái, thời gian cập nhật, người tạo
                ");");

        // Bảng lớp học kế thừa từ bảng chung (Class table - extends Base)
        db.execSQL("CREATE TABLE class (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "majorId INTEGER, " +  // Liên kết với ngành học
                baseColumns + ", " +
                "FOREIGN KEY (majorId) REFERENCES major(id)" +  // Khóa ngoại tới bảng ngành học
                ");");

        // Bảng quan hệ nhiều-nhiều giữa sinh viên và lớp học (Student-Class relationship - many-to-many)
        db.execSQL("CREATE TABLE student_class (" +
                "studentId INTEGER, " +
                "classId INTEGER, " +
                "PRIMARY KEY(studentId, classId), " + // Thiết lập khóa chính là sự kết hợp giữa studentId và classId
                "FOREIGN KEY (studentId) REFERENCES student(id), " +  // Khóa ngoại tới bảng sinh viên
                "FOREIGN KEY (classId) REFERENCES class(id)" +  // Khóa ngoại tới bảng lớp học
                ");");

        // Bảng quan hệ nhiều-nhiều giữa giáo viên và lớp học (Teacher-Class relationship - many-to-many)
        db.execSQL("CREATE TABLE teacher_class (" +
                "teacherId INTEGER, " +
                "classId INTEGER, " +
                "PRIMARY KEY(teacherId, classId), " + // Thiết lập khóa chính là sự kết hợp giữa teacherId và classId
                "FOREIGN KEY (teacherId) REFERENCES teacher(id), " +  // Khóa ngoại tới bảng giáo viên
                "FOREIGN KEY (classId) REFERENCES class(id)" +  // Khóa ngoại tới bảng lớp học
                ");");

        // Bảng điểm kế thừa từ bảng chung (Grade table - extends Base)
        db.execSQL("CREATE TABLE grade (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "score REAL, " +
                "studentId INTEGER, " +  // Liên kết với sinh viên
                "status TEXT, " +
                "updatedTime INTEGER, " +
                "updatedBy TEXT, " +
                "createdTime INTEGER, " +
                "createdBy TEXT, " +
                "FOREIGN KEY (studentId) REFERENCES student(id)" +  // Khóa ngoại tới bảng sinh viên
                ");");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Khi nâng cấp cơ sở dữ liệu, xóa các bảng cũ
        db.execSQL("DROP TABLE IF EXISTS grade");
        db.execSQL("DROP TABLE IF EXISTS student_class");
        db.execSQL("DROP TABLE IF EXISTS teacher_class");
        db.execSQL("DROP TABLE IF EXISTS student");
        db.execSQL("DROP TABLE IF EXISTS teacher");
        db.execSQL("DROP TABLE IF EXISTS class");
        db.execSQL("DROP TABLE IF EXISTS major");
        db.execSQL("DROP TABLE IF EXISTS user");
        // Tạo lại cơ sở dữ liệu với cấu trúc mới
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }
    public List<SinhVien> getAllStudents() {

        List<SinhVien> studentList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM student ORDER BY msv ASC", null);
//        String[] columnNames = cursor.getColumnNames();
//        for (String columnName : columnNames) {
//            System.out.println("Column in student table: " + columnName);
//        }
        if (cursor.moveToFirst()) {
            do {
                String studentIdCard = cursor.getString(cursor.getColumnIndexOrThrow("msv"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String dob = cursor.getString(cursor.getColumnIndexOrThrow("dob"));
                SinhVien student = new SinhVien(studentIdCard, name, dob);
                studentList.add(student);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return studentList;
    }


    public boolean deleteStudent(String msv) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("student", new String[]{"userId"}, "msv = ?",
                    new String[]{msv}, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                int userId = cursor.getInt(cursor.getColumnIndexOrThrow("userId"));
                System.out.println("get userId " + userId);
                int deletedRowsUser = db.delete("user", "id = ?", new String[]{String.valueOf(userId)});
//                int deletedRowsStudent = db.delete("student", "msv = ?", new String[]{msv});
//                System.out.println("DeleteStudent User rows deleted: " + deletedRowsUser + ", Student rows deleted: " + deletedRowsStudent);
//                return deletedRowsUser > 0 && deletedRowsStudent > 0;
                return deletedRowsUser > 0 ;
            } else {
                System.out.println("DeleteStudent No matching student found for MSV: " + msv);
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }






    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM user WHERE userName = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USER, null, values);
        db.close();
        return result != -1;
    }

    // Method to check if a username exists
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=?", new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public boolean registerStudent(String studentIdCard, String name, String dob) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues userValues = new ContentValues();
        userValues.put(COLUMN_USERNAME, name);
        userValues.put(COLUMN_PASSWORD, studentIdCard);
        long userId = db.insert(TABLE_USER, null, userValues);  // Capture the userId

        // Check if user insertion was successful
        if (userId == -1) {
            db.close();
            return false; // Return false if user registration failed
        }
        ContentValues studentValues = new ContentValues();
        studentValues.put("userId", userId); // Foreign key reference to user
        studentValues.put("msv", studentIdCard);
        studentValues.put("name", name);
        studentValues.put("dob", dob);

        long result = -1;
        try {
            result = db.insert("student", null, studentValues);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error registering student", e);
        } finally {
            db.close();
        }
        return result != -1; // Returns true if insertion was successful
    }


    public List<Khoa> getAllMajors() {
        List<Khoa> majorList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to select all relevant fields from the major table
        Cursor cursor = db.rawQuery("SELECT * FROM major", null);
        if (cursor.moveToFirst()) {
            do {
                String majorName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
                long updatedTime = cursor.getLong(cursor.getColumnIndexOrThrow("updatedTime"));
                String updatedBy = cursor.getString(cursor.getColumnIndexOrThrow("updatedBy"));
                long createdTime = cursor.getLong(cursor.getColumnIndexOrThrow("createdTime"));
                String createdBy = cursor.getString(cursor.getColumnIndexOrThrow("createdBy"));

                // Create a new Khoa object with the retrieved data
                Khoa major = new Khoa(majorName, status, updatedTime, updatedBy, createdTime, createdBy);
                majorList.add(major); // Add the major to the list
            } while (cursor.moveToNext());
        }
        cursor.close(); // Close the cursor to free resources
        db.close(); // Close the database connection
        return majorList; // Return the list of Khoa objects
    }


    public List<Lop> getAllClass() {
        List<Lop> classList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to select all relevant fields from the major table
        Cursor cursor = db.rawQuery("SELECT * FROM class", null);
        if (cursor.moveToFirst()) {
            do {
                String majorName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
                long updatedTime = cursor.getLong(cursor.getColumnIndexOrThrow("updatedTime"));
                String updatedBy = cursor.getString(cursor.getColumnIndexOrThrow("updatedBy"));
                long createdTime = cursor.getLong(cursor.getColumnIndexOrThrow("createdTime"));
                String createdBy = cursor.getString(cursor.getColumnIndexOrThrow("createdBy"));

                // Create a new Khoa object with the retrieved data
                Lop lop = new Lop(majorName, status, updatedTime, updatedBy, createdTime, createdBy);
                classList.add(lop); // Add the major to the list
            } while (cursor.moveToNext());
        }
        cursor.close(); // Close the cursor to free resources
        db.close(); // Close the database connection
        return classList; // Return the list of Khoa objects
    }

    public boolean registerMajor(String name, String status, long updatedTime, String updatedBy, long createdTime, String createdBy) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("status", status);
        values.put("updatedTime", updatedTime);
        values.put("updatedBy", updatedBy);
        values.put("createdTime", createdTime);
        values.put("createdBy", createdBy);

        long result = db.insert("major", null, values); // Insert the new major
        db.close(); // Close the database

        return result != -1; // Returns true if the insertion was successful
    }

    public boolean registerClass(String name, String status, long updatedTime, String updatedBy, long createdTime, String createdBy) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("status", status);
        values.put("updatedTime", updatedTime);
        values.put("updatedBy", updatedBy);
        values.put("createdTime", createdTime);
        values.put("createdBy", createdBy);

        long result = db.insert("class", null, values); // Insert the new major
        db.close(); // Close the database

        return result != -1; // Returns true if the insertion was successful
    }

    public boolean updateStudent(String userName, String password, String msv, String fullName, String dob, String majorName, String className) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean isUpdated = true; // Flag to track if all updates succeed

        // First, find the student by msv
        Cursor cursor = db.rawQuery("SELECT * FROM student WHERE msv = ?", new String[]{msv});

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                // Retrieve the userId from the student record
                int userId = cursor.getInt(cursor.getColumnIndexOrThrow("userId")); // Get userId from student table

                // Update user information
                ContentValues user = new ContentValues();
                user.put("userName", userName);
                user.put("password", password);
                int userRowsAffected = db.update("user", user, "id = ?", new String[]{String.valueOf(userId)});
                if (userRowsAffected <= 0) {
                    System.out.println("Error updating user");
                    isUpdated = false; // Mark as failed if no rows were affected
                }

                // Update student information
                ContentValues student = new ContentValues();
                student.put("msv", msv);
                student.put("name", fullName);
                student.put("dob", dob);
                int studentRowsAffected = db.update("student", student, "msv = ?", new String[]{msv});
                if (studentRowsAffected <= 0) {
                    System.out.println("Error updating student");
                    isUpdated = false; // Mark as failed if no rows were affected
                }

                // Update major information
                ContentValues major = new ContentValues();
                major.put("name", majorName);
                int majorRowsAffected = db.update("major", major, "name = ?", new String[]{majorName});
                if (majorRowsAffected <= 0) {
                    System.out.println("Error updating major");
                    isUpdated = false; // Mark as failed if no rows were affected
                }

                // Update class information
                ContentValues classA = new ContentValues();
                classA.put("name", className);
                int classRowsAffected = db.update("class", classA, "name = ?", new String[]{className});
                if (classRowsAffected <= 0) {
                    System.out.println("Error updating class");
                    isUpdated = false; // Mark as failed if no rows were affected
                }

            } else {
                // No student found with the given msv
                System.out.println("No student found with msv: " + msv);
                isUpdated = false; // No update performed
            }
            cursor.close(); // Close the cursor to avoid memory leaks
        } else {
            // Cursor is null, which indicates an error in the query
            System.out.println("Error executing query");
            isUpdated = false; // No update performed
        }

        db.close(); // Close the database connection
        return isUpdated; // Return the final result of the update operation
    }


    public void insertDummyStudents() {
        System.out.println("running dummy ...");
        SQLiteDatabase db = this.getWritableDatabase();

        // Clear the table first (optional, to avoid duplicate dummy data)
        db.delete("student", null, null);
        db.delete("user", null, null);

        String[] dummyUsernames = {"user0","user1", "user2", "user3", "user4", "user5","user6","user7","user8","user9",
               "user10", "user11", "user12", "user13", "user14", "user15","user16","user17","user18","user19",
                "user20", "user21", "user22", "user23", "user24", "user25","user26","user27","user28","admin"
        };

        List<Long> userIdsList = new ArrayList<>();

        for (String username : dummyUsernames) {
            ContentValues userValues = new ContentValues();
            userValues.put(COLUMN_USERNAME, username);
            userValues.put(COLUMN_PASSWORD, username); // Set a default password for all dummy users
            long userId = db.insert(TABLE_USER, null, userValues);

            if (userId == -1) {
                db.close();
                System.out.println("Lỗi thêm mới user");
            }
            if (userId != -1) {
                userIdsList.add(userId);
            }

        }

        // Define some dummy students with example data
        String[][] dummyStudents = {
                {"222A12861", "Nguyễn Văn A", "2000-04-01"},
                {"222A12862", "Trần Thị B", "2000-05-12"},
                {"222A12863", "Lê Văn C", "2000-08-15"},
                {"222A12864", "Phạm Thị D", "2000-09-20"},
                {"222A12865", "Hoàng Văn E", "2000-10-01"},
                {"222A12866", "Cấn Kim F", "2000-11-01"},
                {"222A12867", "Đặng Văn G", "2000-12-01"},
                {"222A12868", "Nguyễn Thị Lan A", "2000-01-01"},
                {"222A12869", "Hoàng Trần Duy N", "2000-02-01"},
                {"222A12870", "Phạm Đức Đ", "2000-03-01"},
                {"222A12871", "Nguyễn Văn A", "2000-04-01"},
                {"222A12872", "Trần Thị B", "2000-05-12"},
                {"222A12873", "Lê Văn C", "2000-06-15"},
                {"222A12874", "Phạm Thị D", "2000-07-20"},
                {"222A12875", "Hoàng Văn E", "2000-08-01"},
                {"222A12876", "Cấn Kim F", "2000-11-01"},
                {"222A12877", "Đặng Văn G", "2000-12-01"},
                {"222A12878", "Vũ Thị Lan H", "2000-01-01"},
                {"222A12879", "Lý Trần Duy N", "2000-02-01"},
                {"222A12880", "Trịnh Đức Đ", "2000-09-01"},
                {"222A12881", "Trịnh Văn A", "2000-04-02"},
                {"222A12882", "Lý Thị B", "2000-05-13"},
                {"222A12883", "Vũ Văn C", "2000-06-16"},
                {"222A12884", "Đặng Thị D", "2000-07-21"},
                {"222A12885", "Cấn Văn E", "2000-08-02"},
                {"222A12886", "Cấn Văn T", "2000-11-03"},
                {"222A12887", "Phạm Văn G", "2000-12-02"},
                {"222A12888", "Lê Thị Lan H", "2000-01-02"},
                {"222A12889", "Trần Trần Duy N", "2000-02-02"},
                {"222A12890", "Nguyễn Đức Đ", "2000-09-02"},
        };

        // Insert each dummy student into the database
        for (int i = 0; i < dummyStudents.length && i < userIdsList.size(); i++) {
            ContentValues studentValues = new ContentValues();
            studentValues.put("userId", userIdsList.get(i));
            studentValues.put("msv", dummyStudents[i][0]);// Student ID
            studentValues.put("name", dummyStudents[i][1]); // Student Name
            studentValues.put("dob", dummyStudents[i][2]);// Date of Birth


            // Insert the row
            try {
                db.insert("student", null, studentValues);

                Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM student", null);
                if (cursor.moveToFirst()) {
                    int count = cursor.getInt(0);
//                    System.out.println("thêm mới student thành công ");
//                    System.out.println("Total students in the table: " + count);
                }
                cursor.close();
            } catch (Exception e) {
                System.out.println(e);
                System.out.println("thêm mới student thất bại !");
            }

        }

        db.close();
    }

}

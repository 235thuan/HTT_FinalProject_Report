package com.example.duanquanlysinhvien.model;

public class SinhVien {
    private int id;
    private String name;
    private String msv;
    private String dob;
    private int age;

    public SinhVien(String name) {
        this.name = name;
    }
    public SinhVien(int id, String studentIdCard, String name, String dob, int age) {
        this.id = id;
        this.msv = studentIdCard;
        this.name = name;
        this.dob = dob;
        this.age = age;
    }
    public SinhVien(String studentIdCard, String name, String dob) {
        this.msv = studentIdCard;
        this.name = name;
        this.dob = dob;
    }
    public SinhVien(String msv, String name) {
        this.msv = msv;
        this.name = name;
    }

    public int getId() { return id; }
    public String getMsv() { return msv; }
    public String getName() { return name; }
    public String getDob() { return dob; }
    public int getAge() { return age; }
}

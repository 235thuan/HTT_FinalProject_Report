package com.example.duanquanlysinhvien;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.auth.DangKy;
import com.example.duanquanlysinhvien.auth.DangNhap;
import com.example.duanquanlysinhvien.csdl.DatabaseHelper;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the button by its ID
        Button btnDangKy = findViewById(R.id.btnDangKy);
        ImageView btnDangNhap = findViewById(R.id.login);

        // Set an OnClickListener on the button
        btnDangKy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start MenuActivity
                Intent intent = new Intent(MainActivity.this, DangKy.class);
                startActivity(intent);
            }
        });
        // Set an OnClickListener on the button
        btnDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLoginPopup(v);
            }
        });
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.insertDummyStudents();
    }

    private void showLoginPopup(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view, 0, 0, R.style.CustomPopupMenuContainer);
        popupMenu.getMenuInflater().inflate(R.menu.login_menu, popupMenu.getMenu());

        // Handle clicks on menu items
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(item.getItemId()==R.id.menu_login) {
                    Intent loginIntent = new Intent(MainActivity.this, DangNhap.class);
                    startActivity(loginIntent);
                    return true;
                } else if(item.getItemId()==R.id.menu_exit) {
                    finishAffinity();
                    return true;
                } else {
                    return false;
                }

            }
        });

        popupMenu.show();

    }
}
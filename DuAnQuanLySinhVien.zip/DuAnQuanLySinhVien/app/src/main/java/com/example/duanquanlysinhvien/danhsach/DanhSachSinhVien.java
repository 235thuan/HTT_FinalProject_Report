package com.example.duanquanlysinhvien.danhsach;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.duanquanlysinhvien.csdl.DatabaseHelper;
import com.example.duanquanlysinhvien.R;
import com.example.duanquanlysinhvien.model.SinhVien;
import com.example.duanquanlysinhvien.adapter.SinhVienAdapter;
import com.example.duanquanlysinhvien.sinhvien.SinhVienThem;

import java.util.ArrayList;
import java.util.List;

public class DanhSachSinhVien extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private ListView lvMenuSinhVien;
    private SinhVienAdapter adapter;
    private List<SinhVien> originalStudentList; // Store the original list
    private TextView tvNoResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_danh_sach_sinh_vien);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView menu_back = findViewById(R.id.menu_back);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbHelper = new DatabaseHelper(this);

        lvMenuSinhVien = findViewById(R.id.lv_menuSinhVien);
        ImageView imgThemMoiSinhVien = findViewById(R.id.imgThemMoiSinhVien);
        tvNoResults = findViewById(R.id.tv_no_results);

        // Load initial student data
        loadStudentData();

        imgThemMoiSinhVien.setOnClickListener(v -> {
            Intent intent = new Intent(DanhSachSinhVien.this, SinhVienThem.class);
            startActivity(intent);
        });
        menu_back.setOnClickListener(v -> {
            Intent intent = new Intent(DanhSachSinhVien.this, DanhSachChucNang.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStudentData();
    }

    private void loadStudentData() {
//        dbHelper.insertDummyStudents();
        originalStudentList = dbHelper.getAllStudents();

//        for (SinhVien item : originalStudentList) {
//            System.out.println("Student retrieved: " + item.getMsv() + ", " + item.getName() + ", " + item.getDob());
//        }
        if (originalStudentList.isEmpty()) {
            Toast.makeText(this, "No students found.", Toast.LENGTH_SHORT).show();
        }
        try {
//            System.out.println("Chạy tạo adapter !");
            adapter = new SinhVienAdapter(this, originalStudentList);
        } catch (Exception e) {
            System.out.println("lỗi tạo adapter " + e);
        }
        try {
//            System.out.println("Chạy tạo view menu cho adapter !");
            lvMenuSinhVien.setAdapter(adapter);
        } catch (Exception e) {
            System.out.println("Lỗi sét adapter to view " + e);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_danh_sach_sinh_vien, menu);
        MenuItem searchItem = menu.findItem(R.id.menu_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setQueryHint("Tìm kiếm sinh viên ...");
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchView.clearFocus();
                if (!query.isEmpty()) {
                    filterStudentList(query); // Perform filtering only if there's input
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.isEmpty()) {
                    // Show original list when the search is cleared

                    adapter.updateList(dbHelper.getAllStudents());
                    tvNoResults.setVisibility(View.GONE);
                    lvMenuSinhVien.setVisibility(View.VISIBLE);
                } else {
                    filterStudentList(newText); // Filter list as text changes
                }
                return true;
            }
        });

        // Reset to full list when the search view is closed
        searchView.setOnCloseListener(() -> {
            adapter.updateList(dbHelper.getAllStudents());
            tvNoResults.setVisibility(View.GONE);
            lvMenuSinhVien.setVisibility(View.VISIBLE);
            loadStudentData();
            return false;
        });
        searchItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                // Optional: Add behavior when SearchView expands
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                // Reset to original list when the search view is collapsed
                adapter.updateList(originalStudentList);
                tvNoResults.setVisibility(View.GONE);
                lvMenuSinhVien.setVisibility(View.VISIBLE);
                searchView.setQuery("", false);
                loadStudentData();
                return true; // Return true to allow collapse action
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_back) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void filterStudentList(String query) {
        List<SinhVien> filteredList = new ArrayList<>();
        for (SinhVien student : dbHelper.getAllStudents()) {
            if (student.getName().toLowerCase().contains(query.toLowerCase()) ||
                    student.getMsv().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(student);
            }
        }

        adapter.updateList(filteredList);

        if (filteredList.isEmpty()) {
            lvMenuSinhVien.setVisibility(View.GONE);
            tvNoResults.setVisibility(View.VISIBLE);
        } else {
            lvMenuSinhVien.setVisibility(View.VISIBLE);
            tvNoResults.setVisibility(View.GONE);
        }
    }
}
